<?php

include("../config/db.php");

include("includes/header.php");

include("includes/sidebar.php");

$total=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM reports"));

$pending=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM reports WHERE status='Pending'"));

$assigned=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM reports WHERE status='Assigned'"));

$resolved=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM reports WHERE status='Resolved'"));

?>

<div class="main">

<h1>Dashboard</h1>

<br>

<div class="cards">

<div class="card">
<h2><?= $total ?></h2>
<p>Total Reports</p>
</div>

<div class="card">
<h2><?= $pending ?></h2>
<p>Pending</p>
</div>

<div class="card">
<h2><?= $assigned ?></h2>
<p>Assigned</p>
</div>

<div class="card">
<h2><?= $resolved ?></h2>
<p>Resolved</p>
</div>

</div>

<h2>Latest Reports</h2>

<br>

<?php include("reports.php"); ?>

</div>

<?php include("includes/footer.php"); ?>