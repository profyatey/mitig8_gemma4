<?php

include("../config/db.php");

/*
|--------------------------------------------------------------------------
| Search & Filter
|--------------------------------------------------------------------------
*/

$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$status = isset($_GET['status']) ? trim($_GET['status']) : "";

/*
|--------------------------------------------------------------------------
| Build Query
|--------------------------------------------------------------------------
*/

$sql = "SELECT * FROM reports WHERE 1=1";

$params = [];
$types = "";

if (!empty($search)) {
    $sql .= " AND description LIKE ?";
    $params[] = "%" . $search . "%";
    $types .= "s";
}

if (!empty($status)) {
    $sql .= " AND status = ?";
    $params[] = $status;
    $types .= "s";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();

$result = $stmt->get_result();

$totalReports = $result->num_rows;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports</title>
    <link rel="stylesheet" href="css/style.css">         
</head>
<body>
<br>
<h2>Reports</h2>
<br>

<p><strong>Total Results:</strong> <?= $totalReports; ?></p>

<form method="GET">

    <input
        type="text"
        name="search"
        placeholder="Search description..."
        value="<?= htmlspecialchars($search); ?>">

    <select name="status">
        <option value="">All Status</option>
        <option value="Pending" <?= ($status=="Pending") ? "selected" : ""; ?>>Pending</option>
        <option value="Assigned" <?= ($status=="Assigned") ? "selected" : ""; ?>>Assigned</option>
        <option value="Resolved" <?= ($status=="Resolved") ? "selected" : ""; ?>>Resolved</option>
    </select>

    <button class="btn">Search</button>
    <a class="btn" href="reports.php">Reset</a>

</form>

<br>

<table>
<tr>
    <th>ID</th>
    <th>Image</th>
    <th>Description</th>
    <th>Risk</th>
    <th>Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['id']; ?></td>
    <td>
        <img src="/FloodMitigation/uploads/<?= htmlspecialchars($row['image']); ?>" class="zoomable-img" width="100">
    </td>
    <td><?= htmlspecialchars($row['description']); ?></td>
    <td><?= htmlspecialchars($row['risk_level']); ?></td>
    <td><?= htmlspecialchars($row['status']); ?></td>
    <td><?= $row['created_at']; ?></td>
    <td>
        <a class="btn" href="report_details.php?id=<?= $row['id']; ?>">View</a>
        <a class="btn" href="update_status.php?id=<?= $row['id']; ?>">Update</a>
    </td>
</tr>
<?php } ?>
</table>

<script src="js/lightbox.js"></script>

</body>
</html>