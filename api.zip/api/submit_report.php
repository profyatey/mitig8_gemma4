<?php
ob_clean();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

header("Content-Type: application/json");
include("../config/db.php");
include("../config/huggingface.php");

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Only POST requests are allowed."
    ]);
    exit;
}

if (
    !isset($_FILES['image']) ||
    !isset($_POST['latitude']) ||
    !isset($_POST['longitude']) ||
    !isset($_POST['description'])
) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required fields."
    ]);
    exit;
}

$user_id = $_POST['user_id'] ?? 1;
$image = $_FILES['image'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$description = $_POST['description'];

if (!is_numeric($latitude) || !is_numeric($longitude)) {
    echo json_encode([
        "success" => false,
        "message" => "Latitude and longitude must be valid numbers."
    ]);
    exit;
}

$uploadDir = "../uploads/";

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$imageName = time() . "_" . basename($image["name"]);
$imagePath = $uploadDir . $imageName;

if (!move_uploaded_file($image["tmp_name"], $imagePath)) {
    echo json_encode([
        "success" => false,
        "message" => "Image upload failed."
    ]);
    exit;
}

// =======================================================
// 🤖 AI ANALYSIS — Gemma 4 (multimodal) via Hugging Face
// =======================================================

$aiResult = analyzeDrainageImage($imagePath, $description);

$riskLevel   = $aiResult['risk_level'];
$aiReasoning = $aiResult['reasoning'];
$status      = "Pending"; // always starts Pending regardless of AI risk; NADMO triages from there

$stmt = $conn->prepare("
    INSERT INTO reports 
    (user_id, image, latitude, longitude, description, risk_level, status, ai_reasoning) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "isddssss",
    $user_id,
    $imageName,
    $latitude,
    $longitude,
    $description,
    $riskLevel,
    $status,
    $aiReasoning
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Success! Image uploaded, saved, and analyzed by AI.",
        "report_id" => $conn->insert_id,
        "ai_analysis" => [
            "risk_level" => $riskLevel,
            "reasoning" => $aiReasoning
        ]
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => $stmt->error
    ]);
}

$stmt->close();
$conn->close();


/**
 * Sends the uploaded drainage image + description to Gemma 4 (multimodal)
 * via Hugging Face's OpenAI-compatible chat completions router, and
 * returns a normalized ['risk_level' => 'High'|'Low', 'reasoning' => string].
 *
 * Fails soft: if the API call errors out or times out, returns a safe
 * fallback rather than blocking the citizen's submission.
 */
function analyzeDrainageImage($imagePath, $description) {

    $fallback = [
        "risk_level" => "Low",
        "reasoning"  => "AI analysis unavailable at time of submission — needs manual review."
    ];

    if (!file_exists($imagePath)) {
        return $fallback;
    }

    $mime = mime_content_type($imagePath);
    $base64Image = base64_encode(file_get_contents($imagePath));
    $dataUri = "data:{$mime};base64,{$base64Image}";

    $prompt = "You are assisting a flood mitigation triage system for NADMO in Ghana. "
        . "Analyze this citizen-submitted photo of a drainage system, along with the "
        . "citizen's description: \"{$description}\". "
        . "Assess flood risk severity based on visible blockage, standing water, debris, "
        . "or structural damage. "
        . "Respond ONLY with a raw JSON object, no markdown, no code fences, in this exact format: "
        . '{"risk_level": "High" or "Low", "reasoning": "1-2 sentence explanation"}';

    $payload = [
        "model" => HF_MODEL,
        "messages" => [
            [
                "role" => "user",
                "content" => [
                    [
                        "type" => "image_url",
                        "image_url" => ["url" => $dataUri]
                    ],
                    [
                        "type" => "text",
                        "text" => $prompt
                    ]
                ]
            ]
        ],
        "max_tokens" => 300
    ];

    $ch = curl_init("https://router.huggingface.co/v1/chat/completions");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer " . HF_TOKEN,
            "Content-Type: application/json"
        ],
        CURLOPT_TIMEOUT => 45, // serverless models can cold-start; give it room
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError || $httpCode !== 200 || !$response) {
        error_log("HF Gemma 4 call failed: HTTP $httpCode | $curlError | $response");
        return $fallback;
    }

    $decoded = json_decode($response, true);
    $rawText = $decoded['choices'][0]['message']['content'] ?? null;

    if (!$rawText) {
        error_log("HF Gemma 4 response had no content: " . $response);
        return $fallback;
    }

    // Strip accidental markdown code fences before parsing
    $clean = preg_replace('/```json|```/', '', $rawText);
    $clean = trim($clean);

    $parsed = json_decode($clean, true);

    if (
        json_last_error() === JSON_ERROR_NONE &&
        isset($parsed['risk_level']) &&
        in_array($parsed['risk_level'], ['High', 'Low'])
    ) {
        return [
            "risk_level" => $parsed['risk_level'],
            "reasoning"  => $parsed['reasoning'] ?? "No reasoning provided."
        ];
    }

    error_log("HF Gemma 4 response wasn't valid JSON: " . $rawText);
    return $fallback;
}